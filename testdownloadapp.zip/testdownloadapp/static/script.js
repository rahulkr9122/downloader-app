const form = document.getElementById('download-form');
const urlInput = document.getElementById('video-url');

form.addEventListener('submit', (event) => {
  const url = urlInput.value.trim();
  if (!url) {
    event.preventDefault();
    alert('Please paste a YouTube or Instagram video URL.');
    return;
  }

  if (!/^https?:\/\//i.test(url)) {
    event.preventDefault();
    alert('Please enter a valid URL starting with http:// or https://');
  }
});
